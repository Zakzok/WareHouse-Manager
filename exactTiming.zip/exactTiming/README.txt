These files contain plenty of unfinished relics, please ignore them.
Run enshp-2020 shortsited/default by following the same instructions as in the main model.
Note that this problem file creates some interesting behavior, you can observe it by 
following the instructions in the comments.